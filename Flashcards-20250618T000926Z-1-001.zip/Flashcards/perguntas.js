criaCartao(
    'Programação',
    'O que é Python?',
    'O Python é uma linguagem de programação'
)

criaCartao(
    'Programação',
    'O que é HTML?',
    'linguagem de marcação usada para criar a estrutura e o conteúdo das páginas da web.'
)

criaCartao(
    'Programação',
    'O que é uma função?',
    'Uma função é um bloco de código que executa alguma tarefa'
)

criaCartao(
    'Lingua inglesa',
    'Como se diz oi em Inglês?',
    'Oi em ingles é Hi'
)

criaCartao(
    'Lingua inglesa',
    'Qual é a tradução de "Obrigado" em inglês?',
    'Obrigado em inglês é Thank you.'
)

criaCartao(
    'Lingua inglesa',
    'Como se pergunta "Qual é o seu nome?" em inglês?',
    'Qual é o seu nome? em inglês é What is your name?'
)

criaCartao(
    'Sociologia',
    'O que é sociedade?',
    'Um grupo de pessoas que vivem juntas, compartilham costumes, leis e valores comuns.'
)

criaCartao(
    'Sociologia',
    'O que é cultura?',
    'É o conjunto de conhecimentos, costumes, línguas, crenças e formas de vida de um povo.'
)

criaCartao(
    'Sociologia',
    'Por que as pessoas têm diferentes costumes?',
    'Porque cada grupo ou comunidade tem suas próprias tradições e maneiras de viver, que são influenciadas pelo lugar onde vivem e pela história de cada um.'
)

criaCartao(
    'Geografia',
    'Qual é o maior país do mundo em área?',
    'Obviamente a Rússia.'
)

criaCartao(
    'Geografia',
    'Qual o oceano que banha o Brasil?',
    'É o Oceano Atlântico com 17 estados banhados por este oceano.'
)

criaCartao(
    'Geografia',
    'Qual é o continente onde fica o Egito?',
    'É a África.'
)